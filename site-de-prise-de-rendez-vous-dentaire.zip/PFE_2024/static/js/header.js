    /* La partie header */

    let menu =document.querySelector('.header .menu');
    document.querySelector('#menu-btn').onclick= () =>{
        menu.classList.toggle('active');
    }
    window.onscroll = () =>{
        menu.classList.remove('active');
    }
    
    
    
    function verifform(){
        alert("Votre commander est prise en charge");
    }
    
    
        /* La partie indice */
    
    document.querySelectorAll('.faq .box-container .box h3').forEach(headings=>{
        headings.onclick = () =>{
            headings.parentElement.classList.toggle('active');
        };
    });