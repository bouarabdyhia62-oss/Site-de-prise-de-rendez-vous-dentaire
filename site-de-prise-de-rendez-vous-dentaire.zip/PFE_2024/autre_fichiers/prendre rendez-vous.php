<?php

include 'component/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:login.php');
};
?>

<?php
// Connexion à la base de données
$conn = mysqli_connect('localhost', 'root', '', 'pfe') or die('Connexion échouée');

// Vérification de la soumission du formulaire de rendez-vous
if (isset($_POST['submit_rdv'])) {
    // Échappement des entrées pour éviter les injections SQL
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $number = mysqli_real_escape_string($conn, $_POST['number']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $time = mysqli_real_escape_string($conn, $_POST['time']);

    $reason = mysqli_real_escape_string($conn, $_POST['reason']);

    // Vérification que la date est dans les trois jours suivants ou la même journée
    $today = date('Y-m-d');
    $next_three_days = date('Y-m-d', strtotime('+3 days'));

    // Vérification si la date est vendredi
    $day_of_week = date('N', strtotime($date)); // 1 (lundi) à 7 (dimanche)
    if ($date < $today || $date > $next_three_days || $day_of_week == 5) {
        $msg="Vous pouvez réserver uniquement pour aujourd'hui ou jusqu'à trois jours à l'avance, sauf le vendredi.";
    }

    // Vérification que l'heure n'est pas déjà réservée
    $check_query = "SELECT * FROM `contact_form` WHERE date = '$date' AND time = '$time'";
    $check_result = mysqli_query($conn, $check_query);
    if (mysqli_num_rows($check_result) > 0) {
        $msg="Cette heure est déjà réservée pour cette date.";
    }

    // Vérification de la disponibilité de la période
$check_unavailable_query = "SELECT * FROM `unavailable_slots` WHERE date = '$date' AND start_time <= '$time' AND end_time > '$time'";
$check_unavailable_result = mysqli_query($conn, $check_unavailable_query);
if(mysqli_num_rows($check_result) > 0 || mysqli_num_rows($check_unavailable_result) > 0) {
    $msg = 'Cette heure est déjà réservée ou indisponible pour cette date.';
}


    // Vérification si l'email existe dans la table users
    $check_email_query = "SELECT * FROM `users` WHERE email = '$email'";
    $check_email_result = mysqli_query($conn, $check_email_query);
    if (mysqli_num_rows($check_email_result) == 0) {
        $msg = ' Email n existe pas dans notre base de données. Veuillez créer un compte avant de prendre rendez-vous.  <a href="register1.php">Créez un compte</a>. ';
    } else {
        // Insertion des données dans la table contact_form
        $insert = mysqli_query($conn, "INSERT INTO `contact_form` (name, email, number, date, time, reason,user_id)
        VALUES ('$name','$email','$number','$date','$time','$reason',$user_id)") or die('Échec de la requête de rendez-vous');
        $msg="Ajout effectué avec succès";
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prendre rendez-vous</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <!--Style CSS-->
    <link rel="stylesheet" href="../static/css/index1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.min.js">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <script type="text/javascript"
        src="http://me.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=xODmJNrF8CWXt3FmVE2PuhmlVc9b033PLAjMDcX885mn_hIfM1UW1kdkcYgM7Gcm"
        charset="UTF-8"></script>
    <link rel="stylesheet" crossorigin="anonymous"
        href="http://me.kis.v2.scr.kaspersky-labs.com/E3E8934C-235A-4B0E-825A-35A08381A191/abn/main.css?attr=aHR0cDovL2xvY2FsaG9zdC9QRkUv">

        <style>
            span {
              color: #333;
            }
            .box {
            background-color: #f0f0f0; /* Gris clair */
        }
            .faq-title {
            color: white; /* Change the color of h3 titles to white */
            }
    </style>
            
        </style>
</head>

<body>
    <?php include './header1.php' ?>

 

    <!--Début de la partie contact-->
<section class="contact" id="contact">
    <h1 class="heading">Prendre un rendez-vous</h1>
    <?php if(!empty($msg)): ?>
         <p style="background-color: black; color: white; padding: 10px; font-size: 18px; text-align: center; "><?php echo $msg; ?></p>
         <br>
      <?php endif; ?>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <span>Votre nom :</span>
        <input type="text" name="name" placeholder="Entrez votre nom complet" class="box" required>

        <!-- Utilisez l'e-mail de l'utilisateur connecté -->
        <span>Votre email :</span>
        <input type="email" name="email" value="<?php echo $_SESSION['user_email']; ?>" class="box" required readonly>

        <span>Votre numéro de téléphone :</span>
        <input type="tel" name="number" placeholder="Entrez votre numéro de téléphone" class="box"
            pattern="[0-9]{10}" title="Veuillez entrer un numéro de téléphone valide (10 chiffres)" required>

        <span>Date de rendez-vous :</span>
        <input type="date" id="date" name="date" class="box">

        <span>Heure de rendez-vous :</span>
        <select id="time" name="time" class="box">

        </select>

        <span>Raison de votre rendez-vous ?</span>
        <select class="box" name="reason">
            <option value="Examen/nettoyage">Examen/nettoyage</option>
            <option value="Urgence">Urgence</option>
            <option value="Orthodontie">Orthodontie</option>
            <option value="Obturation(plombage)">Obturation(plombage)</option>
            <option value="Chirurgie">Chirurgie</option>
        </select>

        <input type="submit" value="Prendre rendez-vous" name="submit_rdv" class="link-btn" style="background-color:#00b8b8">
    </form>
</section>
<!--Fin de la partie contact-->

    <!--Début de la partie indice-->

    <section class="faq" id="faq">
       <h1 class="heading">Indice</h1>
       <div class="box-container">
        <div class="box">
            <h3 class="faq-title"><span>Comment annuler un rendez-vous ?</span><i class="fas fa-angle-down"></i></h3>
            <p>Pour annuler un rendez-vous, veuillez consulter la catégorie "Mes Rendez-vous" dans votre espace personnel, puis cliquer sur l'option "Annuler". En cas de problème, n'hésitez pas à nous contacter.</p>
        </div>
        <div class="box">
            <h3 class="faq-title"><span>Comment prendre un Rendez vous ?</span><i class="fas fa-angle-down"></i></h3>
            <p>Remplissez simplement le formulaire en ligne avec vos informations. Assurez-vous de sélectionner la date et l'heure souhaitées parmi les options disponibles.</p>
        </div>
        <div class="box active">
            <h3 class="faq-title"><span>Comment nous contacter ?</span><i class="fas fa-angle-down"></i></h3>
            <p>N'hésitez pas à nous contacter via notre plateforme en ligne ou en utilisant les coordonnées disponibles en bas de la page.</p>
        </div>
        <div class="box active">
            <h3 class="faq-title"><span>Quels sont nos services ?</span><i class="fas fa-angle-down"></i></h3>
            <p>Notre site propose une gamme de services pour votre santé bucco-dentaire. Pour plus d'informations, veuillez visiter la section 'Services'.</p>
        </div>
        <div class="box active">
            <h3 class="faq-title"><span>Savoir plus sur vous et votre cabinet dentaire</span><i class="fas fa-angle-down"></i></h3>
            <p>Pour plus d'informations sur nous et notre cabinet dentaire, veuillez visiter la section 'À propos'</p>
        </div>
        <div class="box active">
            <h3 class="faq-title"><span>Expérience client</span><i class="fas fa-angle-down"></i></h3>
            <p>N'hésitez pas à partager votre expérience client au sein de notre cabinet. Votre retour est précieux pour nous améliorer continuellement.</p>
        </div>
       </div>
    </section>

    <!--Fin de la partie contact-->


    <?php include './footer.php' ?>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var today = new Date();
            console.log("Actuel date: ", today)
            var maxDate = new Date();
            maxDate.setDate(today.getDate() + 3); // Permet le jour actuel et les deux jours suivants

            var dateInput = document.getElementById('date');
            dateInput.setAttribute('min', formatDate(today));
            dateInput.setAttribute('max', formatDate(maxDate));

            var disabledDays = [5];
            dateInput.addEventListener('input', function() {
            var selectedDate = new Date(this.value);
            if (disabledDays.includes(selectedDate.getDay())) {
                alert("Les rendez-vous ne sont pas disponibles les Vendredis.");
                this.value = ''; // Efface la date sélectionnée
            }
        });
        });

        // Fonction pour formater la date au format YYYY-MM-DD
        function formatDate(date) {
            var year = date.getFullYear();
            var month = (date.getMonth() + 1).toString().padStart(2, '0');
            var day = date.getDate().toString().padStart(2, '0');
            return year + '-' + month + '-' + day;
        }
    </script>
    <script>
        $(document).ready(function () {
            $('#date').change(function () {
                var selected_date = $(this).val();
                $.ajax({
                    url: 'load_times.php',
                    type: 'POST',
                    data: {
                        date: selected_date
                    },
                    success: function (response) {
                        //console.log(response)
                        $('#time').html(response);
                    }
                });
            });
        });

    </script>

    <script src="../static/js/javascript1.js"></script>
</body>

</html>