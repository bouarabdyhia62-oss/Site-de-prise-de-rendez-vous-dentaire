<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<header class="header">

   <section class="flex">

      <a href="dashboard.php" class="logo">Panneau<span>Admin</span></a>

      <nav class="navbar">
         <a href="dashboard.php">Accueil</a>
         <a href="../admin/ad1.php">calendrier</a>
         <a href="../admin/admin_accounts.php">admins</a>
         <a href="../admin/admin_message.php">Message</a>
         <a href="../admin/users_account.php">Utilisateurs</a>
         <a href="../admin/admin_comment.php">Commentaires</a>
         <a href="messages.php">Rendez-vous</a>
      </nav>

      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="user-btn" class="fas fa-user"></div>
      </div>

      <div class="profile">
         <?php
            $select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
            $select_profile->execute([$admin_id]);
            $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
         ?>
         <p><?= $fetch_profile['name']; ?></p>
         <a href="update_profile.php" class="btn">Mettre à jour le profil</a>
         
         <a href="../component/admin_logout.php" onclick="return confirm('Déconnexion de ce site web ?');" class="delete-btn">Déconnexion</a>
      </div>

   </section>

</header>