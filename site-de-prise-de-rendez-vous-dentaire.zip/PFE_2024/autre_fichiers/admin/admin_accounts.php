<?php
include '../component/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   // Vérification que l'ID n'est pas égal à 1 avant de supprimer
   if($delete_id != 1){
      $delete_admin = $conn->prepare("DELETE FROM `admin` WHERE id = ?");
      $delete_admin->execute([$delete_id]);
   }
   header('location:admin_accounts.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Comptes administrateurs</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../../static/css/admin_style.css">

</head>
<body>

<?php include '../component/admin_header.php' ?>

<!-- admins accounts section starts  -->

<section class="accounts">

   <h1 class="heading">Comptes administrateurs</h1>

   <div class="box-container">

   <?php
   // Affiche le bouton "Ajouter un admin" seulement si l'ID de l'administrateur est égal à 1
   if($admin_id == 1){
   ?>
   <div class="box">
      <p>Ajouter un admin</p>
      <a href="register_admin.php" class="option-btn">Ajouter</a>
   </div>
   <?php
   }
   ?>

   <?php
      $select_account = $conn->prepare("SELECT * FROM `admin`");
      $select_account->execute();
      if($select_account->rowCount() > 0){
         while($fetch_accounts = $select_account->fetch(PDO::FETCH_ASSOC)){  
   ?>
   <div class="box">
      <p> Identifiant administrateur : <span><?= $fetch_accounts['id']; ?></span> </p>
      <p> Nom d'utilisateur : <span><?= $fetch_accounts['name']; ?></span> </p>
      <div class="flex-btn">
         <?php
            // Affiche le bouton de suppression seulement si l'administrateur actuel a l'ID 1 et l'ID de l'administrateur en cours de traitement n'est pas égal à 1
            if($admin_id == 1 && $fetch_accounts['id'] != 1){
               ?>
               <a href="admin_accounts.php?delete=<?= $fetch_accounts['id']; ?>" class="delete-btn" onclick="return confirm('supprimer ce compte ?');">supprimer</a>
               <?php
            }
            if($fetch_accounts['id'] == $admin_id){
               echo '<a href="update_profile.php" class="option-btn">Mettre À Jour</a>';
            }
         ?>
      </div>
   </div>
   <?php
      }
   }else{
      echo '<p class="empty">Aucun compte disponible</p>';
   }
   ?>

   </div>

</section>

<!-- admins accounts section ends -->
<script src="../../static/js/admin_script.js"></script>

</body>
</html>
