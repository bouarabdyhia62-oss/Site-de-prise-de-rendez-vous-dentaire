<?php

include '../component/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_message = $conn->prepare("DELETE FROM `messages` WHERE id = ?");
   $delete_message->execute([$delete_id]);
   header('location:admin_message.php');
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Messages</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../../static/css/mes message.css">
   <link rel="stylesheet" href="../../static/css/admin_style.css">
   <link rel="stylesheet" href="../../static/css/o.css">


</head>
<body>




<!-- messages section ends -->

<?php include '../component/admin_header.php' ?>

<br><br><br>
<div class="table-container"> <!-- Ajout de la classe table-container -->
<h1 class="heading">Les Messages</h1>

      <table>
         <thead>
            <tr>
               <th>Nom</th>
               <th>Email</th>
               <th>Numéro</th>
               <th>Message</th>
               <th>Action</th>
            </tr>
         </thead>
         <tbody>
            <?php
             $select_messages = $conn->prepare("SELECT * FROM `messages`");
             $select_messages->execute();
              if($select_messages->rowCount() > 0){
                   while($fetch_messages = $select_messages->fetch(PDO::FETCH_ASSOC)){
            ?>
             <tr>
               <td><?= $fetch_messages['name']; ?></td>
               <td><?= $fetch_messages['email']; ?></td>
               <td><?= $fetch_messages['number']; ?></td>
               <td><?= $fetch_messages['message']; ?></td>
               <td class="action">
                  <form method="post">
                     <a href="admin_message.php?delete=<?= $fetch_messages['id']; ?>" class="custom-btn" onclick="return confirm('Supprimer ce message?');">Supprimer</a>
                  </form>
               </td>
            </tr>
            <?php
               }
            } else {
               echo '<tr><td colspan="5" class="empty">Vous n\'avez aucun message ! </td></tr>';
            }
        ?>
         </tbody>
      </table>

   </div>

</section>







<!-- custom js file link  -->
<script src="../../static/js/admin_script.js"></script>

</body>
</html>