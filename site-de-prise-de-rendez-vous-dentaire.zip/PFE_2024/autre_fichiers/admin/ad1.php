
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../static/css/heuredispo.css">
    <link rel="stylesheet" href="../../static/css/admin_style.css">

    <title>Ajouter période indisponible</title>

</head>
 

<body>
<header class="header">

  <section class="flex">

   <a href="dashboard.php" class="logo">Panneau<span>Admin</span></a>

   <nav class="navbar">
      <a href="dashboard.php">Accueil</a>
      <a href="../admin/ad1.php">calendrier</a>
      <a href="admin_accounts.php">admins</a>
      <a href="./admin_message.php">Messages</a>
      <a href="../admin/users_account.php">Utilisateurs</a>
      <a href="../admin/admin_comment.php">Commentaires</a>
      <a href="messages.php">rendez-vous</a>
   </nav>

   <div class="icons">
      <div id="menu-btn" class="fas fa-bars"></div>
      <div id="user-btn" class="fas fa-user"></div>
   </div>
  </section>

</header>
<br><br><br><br>
    
    
    <?php
    // Traitement du formulaire
    if(isset($_POST['submit_unavailable'])) {
        // Connexion à la base de données
        $conn = mysqli_connect('localhost', 'root', '', 'pfe') or die('Connexion échouée');

        // Récupération des données du formulaire
        $date = mysqli_real_escape_string($conn, $_POST['date']);
        $start_time = mysqli_real_escape_string($conn, $_POST['start_time']);
        $end_time = mysqli_real_escape_string($conn, $_POST['end_time']);

        // Insertion des données dans la table unavailable_slots
        $insert = mysqli_query($conn, "INSERT INTO unavailable_slots (date, start_time, end_time)
        VALUES ('$date', '$start_time', '$end_time')") or die('Échec de l\'insertion de la période indisponible');

        // Redirection vers la page d'administration après l'insertion
        header("Location:dashboard.php");
        exit;
    }
    ?>
      

<!-- Formulaire pour ajouter une période indisponible -->

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="unavailability-form">
    <h1 class="form-title">Ajouter période indisponible</h1>
    <label for="date" class="form-label">Date :</label>
    <input type="date" name="date" class="form-input" required><br>
    <label for="start_time" class="form-label">Heure de début :</label>
    <input type="time" name="start_time" class="form-input" required><br>
    <label for="end_time" class="form-label">Heure de fin :</label>
    <input type="time" name="end_time" class="form-input" required><br>
    <input type="submit" name="submit_unavailable" class="form-button" value="Ajouter période indisponible">
</form>
</body>
</html>
