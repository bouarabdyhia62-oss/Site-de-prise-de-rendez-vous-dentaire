<?php

include '../component/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Tableau de bord</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../../static/css/admin_style.css">

</head>
<body>

<?php include '../component/admin_header.php' ?>

<!-- admin dashboard section starts  -->

<section class="dashboard">

   <h1 class="heading">Tableau de bord</h1>

   <div class="box-container">

   <div class="box">
      <h3>Bienvenue!</h3>
      <p><?= $fetch_profile['name']; ?></p>
      <a href="update_profile.php" class="btn">Modifier le profil</a>
   </div>
   <div class="box">
      <h3>Bienvenue!</h3>
      <p><?= $fetch_profile['name']; ?></p>
      <a href="ad1.php" class="btn">Calendrier</a>
   </div>
   <div class="box">
      <?php
         $select_admins = $conn->prepare("SELECT * FROM `admin`");
         $select_admins->execute();
         $numbers_of_admins = $select_admins->rowCount();
      ?>
      <h3><?= $numbers_of_admins; ?></h3>
      <p>Admins</p>
      <a href="admin_accounts.php" class="btn">Les admins</a>
   </div>

   <div class="box">
      <?php
         $select_contact_form = $conn->prepare("SELECT * FROM `contact_form`");
         $select_contact_form->execute();
         $numbers_of_contact_form = $select_contact_form->rowCount();
      ?>
      <h3><?= $numbers_of_contact_form; ?></h3>
      <p> Nouveau rendez-vous</p>
      <a href="messages.php" class="btn">Les rendez-vous</a>
   </div>
   <div class="box">
      <?php
         $select_comments = $conn->prepare("SELECT * FROM `comments`");
         $select_comments->execute();
         $numbers_of_comments = $select_comments->rowCount();
      ?>
      <h3><?= $numbers_of_comments; ?></h3>
      <p> Les commentaires</p>
      <a href="../admin/admin_comment.php" class="btn">Les commentaires</a>
   </div>
   <div class="box">
      <?php
         $select_users = $conn->prepare("SELECT * FROM `users`");
         $select_users->execute();
         $numbers_of_users = $select_users->rowCount();
      ?>
      <h3><?= $numbers_of_users; ?></h3>
      <p>Compte utilisateurs</p>
      <a href="users_account.php" class="btn">Les utilisateurs</a>
   </div> 
   <div class="box">
      <?php
         $select_messages = $conn->prepare("SELECT * FROM `messages`");
         $select_messages->execute();
         $numbers_of_messages = $select_messages->rowCount();
      ?>
      <h3><?= $numbers_of_messages; ?></h3>
      <p>Messages utilisateurs</p>
      <a href="admin_message.php" class="btn">Les messages</a>
   </div> 


</section>

<!-- admin dashboard section ends -->









<!-- custom js file link  -->
<script src="../../static/js/admin_script.js"></script>

</body>
</html>