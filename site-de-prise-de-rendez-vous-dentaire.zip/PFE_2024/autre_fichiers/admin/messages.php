<?php

include '../component/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_message = $conn->prepare("DELETE FROM `contact_form` WHERE id = ?");
   $delete_message->execute([$delete_id]);
   header('location:messages.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>messages</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../../static/css/admin_style.css">
   <link rel="stylesheet" href="../../static/css/o.css">
   

</head>
<body>

<?php include '../component/admin_header.php' ?>
<br><br><br>
<div class="table-container"> <!-- Ajout de la classe table-container -->
<h1 class="heading">Les rendez-vous</h1>

      <table>
         <thead>
            <tr>
               <th>Nom</th>
               <th>Email</th>
               <th>Numéro</th>
               <th>Date</th>
               <th>Heure</th>
               <th>Raison</th>
               <th>action </th>
            </tr>
         </thead>
         <tbody>
            <?php
             $select_contact_form = $conn->prepare("SELECT * FROM `contact_form`");
             $select_contact_form->execute();
              if($select_contact_form->rowCount() > 0){
                   while($fetch_contact_form = $select_contact_form->fetch(PDO::FETCH_ASSOC)){
            ?>
             <tr>
               <td><?= $fetch_contact_form['name']; ?></td>
               <td><?= $fetch_contact_form['email']; ?></td>
               <td><?= $fetch_contact_form['number']; ?></td>
               <td><?= $fetch_contact_form['date']; ?></td>
               <td><?= $fetch_contact_form['time']; ?></td>
               <td><?= $fetch_contact_form['reason']; ?></td>
               <td class="action">   <form method="post">
        
         <a href="messages.php?delete=<?= $fetch_contact_form['id']; ?>" class="custom-btn" onclick="return confirm('delete this message?');">Supprimer</a>

      </form></td>
            </tr>
            <?php
               }
               } else {
                  echo '<tr><td colspan="5" class="empty">Pas de rendez-vous !</td></tr>';
               }
               
            ?>
         </tbody>
      </table>

   </div>

</section>









<!-- custom js file link  -->
<script src="../../static/js/admin_script.js"></script>

</body>
</html>