<?php

include '../component/connect1.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_message = $conn->prepare("DELETE FROM `comments` WHERE id_comm = ?");
   $delete_message->execute([$delete_id]);
   header('location:admin_comment.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Les Commentaires</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../../static/css/admin_style.css">
   <link rel="stylesheet" href="../../static/css/o.css">

</head>
<body>

<?php include '../component/admin_header.php' ?>
<br><br><br>
<div class="table-container">
<h1 class="heading">Les commentaires</h1>

      <table>
         <thead>
            <tr>
               <th>Nom</th>
               <th>Email</th>
               <th>Commentaire</th>
               <th>Action</th>
            </tr>
         </thead>
         <tbody>
        <?php
            $select_comments = $conn->prepare("SELECT users.name AS user_name, comments.email, comments.message, comments.id_comm FROM `comments` JOIN `users` ON users.email = comments.email");
            $select_comments->execute();
            if($select_comments->rowCount() > 0){
              while($fetch_comments = $select_comments->fetch(PDO::FETCH_ASSOC)){
        ?>
             <tr>
               <td><?= $fetch_comments['user_name']; ?></td>
               <td><?= $fetch_comments['email']; ?></td>
               <td><?= $fetch_comments['message']; ?></td>
               <td class="action">
                  <form method="post">
                     <a href="admin_comment.php?delete=<?= $fetch_comments['id_comm']; ?>" class="custom-btn" onclick="return confirm('Supprimer ce commentaire?');">Supprimer</a>
                  </form>
               </td>
            </tr>
            <?php
               }
            } else {
               echo '<tr><td colspan="5" class="empty">Vous n\'avez aucun commentaire ! </td></tr>';
            }
        ?>
         </tbody>
      </table>

   </div>

</section>

<!-- custom js file link  -->
<script src="../../static/js/admin_script.js"></script>

</body>
</html>
