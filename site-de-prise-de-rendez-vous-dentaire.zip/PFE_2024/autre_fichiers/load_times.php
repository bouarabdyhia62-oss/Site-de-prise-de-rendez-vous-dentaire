<?php
// Connexion à la base de données
$conn = mysqli_connect('localhost','root','','pfe') or die('Connexion échouée');

// Récupérer la date sélectionnée
$date = $_POST['date'];

// Générer les options d'heure
$start_time = strtotime('08:30');
$rest_time = strtotime('12:30');
$end_time = strtotime('15:30');
$interval = 60 * 60; // 1 heure en secondes
$options = '';

for ($time = $start_time; $time <= $end_time; $time += $interval) {
    $formatted_time = date('H:i', $time);
    if ($formatted_time === "12:30") {
        continue;}

    // Vérification si l'heure est déjà réservée
    $check_query = "SELECT * FROM `contact_form` WHERE date = '$date' AND time = '$formatted_time'";
    $check_result = mysqli_query($conn, $check_query);
    $check_query_unavailable = "SELECT * FROM `unavailable_slots` WHERE date = '$date' AND start_time <= '$formatted_time' AND end_time > '$formatted_time'";
    $check_result_unavailable = mysqli_query($conn, $check_query_unavailable);
    var_dump($check_result);
    if(mysqli_num_rows($check_result) > 0 || mysqli_num_rows($check_result_unavailable) > 0) {
        $options .= "<option value='$formatted_time' disabled>$formatted_time (Réservée)</option>";
    } else {
        $options .= "<option value='$formatted_time'>$formatted_time</option>";
    }
}

echo $options;
?>
