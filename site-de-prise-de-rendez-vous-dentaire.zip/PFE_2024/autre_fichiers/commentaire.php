<?php
include 'component/connect.php';
session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
   $user_email = $_SESSION['user_email']; // Récupération de l'email de l'utilisateur connecté depuis la session
}else{
   $user_id = '';
   $user_email = '';
   header('location:login.php');
};

$conn = mysqli_connect('localhost','root','','pfe') or die('Connexion échouée');
$msg = "";

if(isset($_POST['submit_comment'])){
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $stars = mysqli_real_escape_string($conn, $_POST['stars']); 

    if($user_id != ''){
        // Insertion des données dans la table comments avec l'email récupéré de la session
        $insert = mysqli_query($conn, "INSERT INTO `comments` (email, message, stars, timestamp)
        VALUES ('$user_email', '$message', '$stars', NOW())") or die('Échec de la requête de commentaire');
        $msg="Ajout effectué avec succès";
    } else {
       $msg = 'Vous devez créer un compte pour poster un commentaire. <a href="register1.php">Créez un compte</a>.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Web d'un cabinet dentaire</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <!-- Style CSS -->
    <link rel="stylesheet" href="../static/css/index1.css">
    <link rel="stylesheet" href="../static/css/style1.css">
    <style>
            span {
              color: #333;
            }
            .comment{
                background-color: #f5f5f5; /* Light gray background for input fields */
            }
          
        .box {
            background-color: #f0f0f0;
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .link-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #00b8b8;
            color: #fff;
            text-transform: uppercase;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            letter-spacing: 2px;
            transition: background-color 0.3s ease;
        }

        .link-btn:hover {
            background-color: #008787;
        }
    
  


    </style>
</head>
<body>
<?php include './header1.php'?>



<!-- Début de la partie commentaire -->
<section class="comment" id="comment">
    <h1 class="heading">Laisser un commentaire</h1>
    <?php if(!empty($msg)): ?>
         <p style="background-color: black; color: white; padding: 10px; font-size: 18px; text-align: center; "><?php echo $msg; ?></p>
         <br>
      <?php endif; ?>
    <form action="./commentaire.php" method="post">      
        <input type="hidden" name="email" value="<?php echo $user_email; ?>">
        <span>Votre message :</span>
        <textarea name="message" placeholder="Entrez votre message" class="box" required=""></textarea>
        <span>Votre évaluation :</span>
        <select name="stars" class="box" required="">
            <option value="1">1 étoile</option>
            <option value="2">2 étoiles</option>
            <option value="3">3 étoiles</option>
            <option value="4">4 étoiles</option>
            <option value="5">5 étoiles</option>
        </select>
        <input type="submit" value="Poster le commentaire" name="submit_comment" class="link-btn" style="background-color:#00b8b8;">
    </form>
</section>
<!-- Fin de la partie commentaire -->

<?php include './footer.php'?>
<script src="../static/js/javascript1.js"></script>
</body>
</html>