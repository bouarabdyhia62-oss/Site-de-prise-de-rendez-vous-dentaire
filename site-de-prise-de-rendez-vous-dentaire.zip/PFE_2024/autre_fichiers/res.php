<?php

include 'component/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:../index.php');
};
if(isset($_POST['delete'])){
   $contact_form_id = $_POST['contact_form_id'];
   $delete_contact_form_item = $conn->prepare("DELETE FROM `contact_form` WHERE id = ?");
   $delete_contact_form_item->execute([$contact_form_id]);
   $msg = 'Rendez-vous annuler!';
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> Mes rendez-vous</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../static/css/s.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'header1.php'; ?>
<!-- header section ends -->

<div class="heading">
   <h3>rendez vous </h3>
   <p><a href="../index.php">Accueil</a> <span> / Rendez-vous</span></p>
</div>

<section class="Rendezvous">

   <h1 class="title"> Mes rendez-vous </h1>
   <?php if(isset($msg)): ?>
         <p style="background-color: black; color: white; padding: 10px; font-size: 18px; text-align: center; "><?php echo $msg; ?></p>
         <br>
      <?php endif; ?>

   <div class="table-container"> <!-- Ajout de la classe table-container -->

      <table>
         <thead>
            <tr>
               <th>Nom</th>
               <th>Email</th>
               <th>Numéro</th>
               <th>Date</th>
               <th>Heure</th>
               <th>Raison </th>
               <th>action </th>
            </tr>
         </thead>
         <tbody>
            <?php
               if($user_id == ''){
                  echo '<tr><td colspan="5" class="empty">Veuillez vous connecter pour voir vos rendez-vous</td></tr>';
               } else {
                  $select_contact_form = $conn->prepare("SELECT * FROM `contact_form` WHERE user_id = ?");
                  $select_contact_form->execute([$user_id]);
                  if($select_contact_form->rowCount() > 0){
                     while($fetch_contact_form = $select_contact_form->fetch(PDO::FETCH_ASSOC)){
            ?>
            <tr>
               <td><?= $fetch_contact_form['name']; ?></td>
               <td><?= $fetch_contact_form['email']; ?></td>
               <td><?= $fetch_contact_form['number']; ?></td>
               <td><?= $fetch_contact_form['date']; ?></td>
               <td><?= $fetch_contact_form['time']; ?></td>
               <td><?= $fetch_contact_form['reason']; ?></td>
               <td>   <form method="post">
         <input type="hidden" name="contact_form_id" value="<?= $fetch_contact_form['id']; ?>">
         <button type="submit" class="custom-button" name="delete" onclick="return confirm('Annuler le rendez-vous ?');">Annuler</button>

      </form></td>
            </tr>
            <?php
               }
               } else {
                  echo '<tr><td colspan="5" class="empty">Pas de rendez-vous !</td></tr>';
               }
               }
            ?>
         </tbody>
      </table>

   </div>

</section>

<!-- footer section starts  -->
<?php include './footer.php'; ?>
<!-- footer section ends -->








<!-- custom js file link  -->
  <!-- <script src="js/script.js"></script> -->

</body>
</html>