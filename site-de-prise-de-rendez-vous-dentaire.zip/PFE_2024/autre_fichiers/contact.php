<?php

include './component/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['send'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $msg = $_POST['msg'];
   $msg = filter_var($msg, FILTER_SANITIZE_STRING);

   $select_message = $conn->prepare("SELECT * FROM `messages` WHERE name = ? AND email = ? AND number = ? AND message = ?");
   $select_message->execute([$name, $email, $number, $msg]);

   if($select_message->rowCount() > 0){
      $message = 'Message déjà envoyé !';
   }else{

      $insert_message = $conn->prepare("INSERT INTO `messages`(user_id, name, email, number, message) VALUES(?,?,?,?,?)");
      $insert_message->execute([$user_id, $name, $email, $number, $msg]);

      $message = 'Message envoyé avec succès !';

   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>contact</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../static/css/contact.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include './header1.php'; ?>

<!-- header section ends -->
<div class="tous">
   <div class="contact-section">  
      <div class="image-container"> 
         <img src="../static/img/PKKKK.jpg" alt="Contactez-nous">
      </div>
         
      <div class="contact-info">     
         

         <form action="" method="post" class="contact-form"> 
            <?php if(!empty($message)): ?>
               <p style="background-color: black; color: white; padding: 10px; font-size: 18px; text-align: center; "><?php echo $message; ?></p>
               <br>
            <?php endif; ?> 
            <h3>Contactez-nous</h3>          
            <input type="text" name="name" maxlength="50" class="input-field" placeholder="Saisissez votre nom" required>
            <input type="email" name="email" maxlength="50" class="input-field" placeholder="Saisissez votre email" required>
            <input type="number" name="number" placeholder="Entrez votre numéro de téléphone" class="input-field"
            pattern="[0-9]{10}" title="Veuillez entrer un numéro de téléphone valide (10 chiffres)" required>
            <textarea name="msg" class="input-field" required placeholder="Saisissez votre message" maxlength="500" cols="30" rows="10"></textarea>
            <input type="submit" value="Envoyer message" name="send" class="submit-btn">
         </form>
      </div>
   </div>
</div>
<!-- contact section ends -->










<!-- footer section starts  -->
<?php include './footer.php'; ?>
<!-- footer section ends -->








<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>