 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicaion Web d'un cabinet dentaire</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <!--Style CSS-->
    <link rel="stylesheet" href="/static/css/style1.css">


    <!-- Ajoutez le CSS pour la partie footer -->
    <style>
        /* Debut de la partie footer */
        .footer{
            background-color: #303030;
            padding: 20px;
            text-align: center;
        }
        .footer .flex{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .footer .flex .box-1{
            margin: 10px;
            flex: 1 1 300px;
            max-width: 300px;
        }
        .footer .flex .box-1 a{
            font-size: 1.5rem;
            display: block;
            margin-bottom: 10px;
            color: #333;
            text-decoration: none;
        }
        .footer .flex .box-1 a span{
            color: #fff;
        }
        .footer .flex .box-1 a:hover span{
            text-decoration: underline;
        }
        .footer .flex .box-1 a i{
            color: #00b8b8;
        }
        .footer .flex .box-1:last-child{
            text-align: right;
        }
        .footer .flex .box-1:last-child a i{
            margin-left: 1.5rem;
        }
        .footer .flex .box-1:first-child a i{
            margin-right: 1.5rem;
        }
        .footer .flex .box-1:nth-child(2){
            text-align: center;
        }
        .footer .credit{
            margin-top: 20px;
            color: #666;
        }
        .footer .credit span{
            color:var(--main-color);
        }
        /* Fin de la partie footer */
    </style>
</head>
<body>




  
  
  <!-- Debut de la partie footer-->
  <footer class="footer">
                <section class="flex">
                    <div class="box-1">
                        <a href="tel:0559302935"><i class="fas fa-phone"><span>        0559302935</span></i></a>
                        <a href="mailto:dentalCare@gmail.com"><i class="fas fa-envelope"><span>        dentalCare@gmail.com</span></i></a>
                        <a href="#"><i class="fas fa-map-marker-alt"><span>       Alger Tizi-Ouzou </span></i></a>
                        <a href="../autre_fichiers/contact.php"><i class="fas fa-paper-plane"><span>        Contactez-nous</span></i></a>
                        
                    </div>
                    <div class="box-1">
                        <a href="../index.php"><span>Accueil</span></a>
                        <a href="../index.php#about"><span>A propos</span></a>
                        <a href="../index.php#aboutservices"><span>Services</span></a>
                        <a href="../index.php#reviews"><span>Avis</span></a>
                        <a href="./prendre rendez-vous.php"><span>Rendez-vous</span></a>
                    </div>
                    <div class="box-1">
                        <a href="#"><i class="bx bxl-facebook"></i>        <span>Facebook</span></a>
                        <a href="#"><i class="bx bxl-twitter"></i>        <span>Twitter</span></a>
                        <a href="#"><i class="bx bxl-linkedin"></i>        <span>Linkedin</span></a>
                        <a href="#"><i class="bx bxl-instagram"></i>        <span>Instagram</span></a>
                    </div>
                </section>
                <div class="credit">©  Droits d'auteur @ 2024 par <span>Mr .Web desinger</span> | Tous droits réservés!</div>
       </footer>
    
    <!-- Fin de la partie footer-->




    

    <script src="/static/js/header.js"></script>
</body>
</html>