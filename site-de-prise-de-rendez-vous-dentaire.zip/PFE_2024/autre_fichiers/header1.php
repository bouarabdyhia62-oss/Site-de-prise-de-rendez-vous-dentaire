


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicaion Web d'un cabinet dentaire</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <!--Style CSS-->
    <link rel="stylesheet" href="../static/css/style1.css">
</head>
<body>



     <!--Début de la partie header-->
<header class="header">




            <nav class="navbar nav-1">
                <section class="flex">
                    <a href="../index.php" class="logo">Dental <span>Care.</span></a>
                    <ul>
                        <li><a href="./prendre rendez-vous.php">Prendre Rendez-Vous   <i class="fas fa-paper-plane"></i></a>
                    </li>
                    </ul>
                </section>
            </nav>
            <nav class="navbar nav-2">
                <section class="flex">
                    <div id="menu-btn" class="fas fa-bars"></div>
                    <div class="menu">
                        <ul>
                            <li><a href="../index.php">Accueil </a></li>

                            <?php if($user_id != ''){ ?>
                             <li><a href="./res.php">Mes rendez-vous</a></li>
                            <?php } ?></li>

                            <li><a href="#">A propos <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="../index.php#cabinet">Cabinet </a></li>
                                    <li><a href="../index.php#dentiste">Dentiste</a></li>
                                    <li><a href="../index.php#heures">Heures d’ouverture</a></li>
                                    <li><a href="../index.php#tarifs">Tarifs</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Services <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="../index.php#implant">Implant Dentaire</a></li><li>
                                    </li><li><a href="../index.php#hollywood">Hollywood Smile</a></li>
                                    <li><a href="../index.php#prothese">Prothèse Dentaire</a></li>
                                    <li><a href="../index.php#blanchiment">Blanchiment Dentaire</a></li>
                                    <li><a href="../index.php#facettes">Facettes Dentaires</a></li>
                                    <li><a href="../index.php#predodontie">Pédodontie</a></li>
                                    <li><a href="../index.php#parod">Parodontologie</a></li>
                                    <li><a href="../index.php#orthodonie">Orthodonie Classique</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Avis <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="./commentaire.php">Laisser Un Commentaire </a></li>
                                    <li><a href="./commentaire.php#reviews">Avis Des Clients</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Contact <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="./prendre rendez-vous.php">Prendre Rendez-Vous</a></li>
                                    <li><a href="./contact.php">Contactez-nous</a></li>
                                    <li><a href="./commentaire.php">Laisser Un Commentaire</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <ul>
                      <li><a href="#">Compte <i class="fas fa-angle-down"></i></a>
                        <ul>
                          <?php if($user_id == ''){ ?>
                            <li><a href="login.php">Connexion</a></li>
                            <li><a href="register1.php">Inscription</a></li>
                          <?php } else { ?>
                            <li><a href="update_profile.php">Modifier le profil</a></li>
                            <li><a href="component/user_logout.php" onclick="return confirm('Déconnexion de cette application web ?');">Déconnexion</a></li>
                          <?php } ?>
                        </ul>
                      </li>
                    </ul>

                </section>
            </nav>
</header>
        <!--Fin de la partie header-->




        <script src="/static/js/header1.js"></script>
    </body>
    </html>