<?php
include 'component/connect.php';

// Initialiser une variable pour stocker les messages
$message = '';

if(isset($_POST['submit'])){
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']);
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ? ");
   $select_user->execute([$email]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   if($select_user->rowCount() > 0){
      $message = "L'email existe déjà";
   }else{
      if($pass != $cpass){
         $message = 'La confirmation du mot de passe ne correspond pas !';
      }else{
         $insert_user = $conn->prepare("INSERT INTO `users`(name, email, number, password) VALUES(?,?,?,?)");
         $insert_user->execute([$name, $email, $number, $cpass]);
         $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ? AND password = ?");
         $select_user->execute([$email, $pass]);
         $row = $select_user->fetch(PDO::FETCH_ASSOC);
         // Vérifier si l'inscription a été effectuée avec succès
         if($select_user->rowCount() > 0){
            // Rediriger vers la page d'accueil
            header("Location: ../index.php");
            exit(); 
         }
      }
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Inscription</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../static/css/l.css">
   <link rel="stylesheet" href="../static/css/style1.css">

</head>
<body>
   
<!--Début de la partie header-->
<header class="header">
            <nav class="navbar nav-1">
                <section class="flex">
                    <a href="../index.php" class="logo">Dental <span>Care.</span></a>
                    <ul>
                        <li><a href="./prendre rendez-vous.php">Prendre Rendez-Vous   <i class="fas fa-paper-plane"></i></a>
                    </li>
                    </ul>
                </section>
            </nav>
            <nav class="navbar nav-2">
                <section class="flex">
                    <div id="menu-btn" class="fas fa-bars"></div>
                    <div class="menu">
                        <ul>
                            <li><a href="../index.php">Accueil </a></li>


                            <li><a href="#">A propos <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="../index.php/#about">Cabinet </a></li>
                                    <li><a href="../index.php#dentiste">Dentiste</a></li>
                                    <li><a href="../index.php#heures">Heures d’ouverture</a></li>
                                    <li><a href="../index.php#tarifs">Tarifs</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Services <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="../index.php#implant">Implant Dentaire</a></li><li>
                                    </li><li><a href="../index.php#hollywood">Hollywood Smile</a></li>
                                    <li><a href="../index.php#prothese">Prothèse Dentaire</a></li>
                                    <li><a href="../index.php#blanchiment">Blanchiment Dentaire</a></li>
                                    <li><a href="../index.php#facettes">Facettes Dentaires</a></li>
                                    <li><a href="../index.php#predodontie">Pédodontie</a></li>
                                    <li><a href="../index.php#parod">Parodontologie</a></li>
                                    <li><a href="../index.php#orthodonie">Orthodonie Classique</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Avis <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="./commentaire.php">Laisser Un Commentaire </a></li>
                                    <li><a href="./commentaire.php#reviews">Avis Des Clients</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Contact <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="./prendre rendez-vous.php">Prendre Rendez-Vous</a></li>
                                    <li><a href="./contact.php">Contactez-nous</a></li>
                                    <li><a href="./commentaire.php">Laisser Un Commentaire</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <ul>
                      <li><a href="#">Compte <i class="fas fa-angle-down"></i></a>
                        <ul>
                        <li><a href="./login.php">Connexion</a></li>
                        <li><a href="./register1.php">Inscription</a></li>  
                        </ul>
                      </li>
                    </ul>

                </section>
            </nav>
</header>
        <!--Fin de la partie header-->
<br><br><br>
<section class="form-container">

   <form action="" method="post">
   <?php if(!empty($message)): ?>
         <p style="background-color: black; color: white; padding: 10px; font-size: 18px; text-align: center; "><?php echo $message; ?></p>
         <br>
      <?php endif; ?>
      <h3>Inscrivez-vous maintenant</h3>
      <input type="text" name="name" required placeholder="Entrez votre nom" class="box" maxlength="50">
      <input type="email" name="email" required placeholder="Entrez votre adresse e-mail" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="number" name="number" required placeholder="Entrez votre numéro de téléphone" class="box" min="0" max="9999999999" maxlength="10">
      <input type="password" name="pass" required placeholder="Entrez votre mot de passe" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="cpass" required placeholder="Confirmez votre mot de passe" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="Inscrivez-vous maintenant" name="submit" class="btn">
      <p>Vous avez déjà un compte ? <a href="login.php">Connectez-vous maintenant</a></p>
   </form>

</section>










<br><br><br><br>  
<?php include './footer.php'; ?>







<!-- custom js file link  -->
<script src="../static/js/javascript1.js"></script>

</body>
</html>
