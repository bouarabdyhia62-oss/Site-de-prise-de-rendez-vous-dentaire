<?php
include 'component/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['submit'])){

   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ? AND password = ?");
   $select_user->execute([$email, $pass]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   if($select_user->rowCount() > 0){
      $_SESSION['user_id'] = $row['id'];
      $_SESSION['user_email'] = $row['email']; // Ajouter cette ligne pour stocker l'email de l'utilisateur dans la session
      header('location:../index.php');
   }else{
      $msg = "Nom d'utilisateur ou mot de passe incorrect !";
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Connexion</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../static/css/l.css">


</head>
<body>
   
<!-- header section starts  -->
<?php include 'header1.php'; ?>
<!-- header section ends -->
<br><br><br> 




<section class="form-container">
   <!-- Display error message -->
   <?php if(isset($msg)): ?>
         <p style="background-color: black; color: white; padding: 10px; font-size: 18px;text-align: center; "><?php echo $msg; ?></p>
         <br>
      <?php endif; ?>
   <form action="" method="post">
      <h3>Connectez-vous maintenant</h3>
      <input type="email" name="email" required placeholder="Entrez votre adresse e-mail" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="pass" required placeholder="Entrez votre mot de passe" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="Connectez-vous maintenant" name="submit" class="btn">
      <p>Vous n’avez pas de compte ? <a href="./register1.php"> Inscrivez-vous maintenant</a></p>
   </form>

</section>










<br><br><br><br>  
<?php include './footer.php'; ?>





<!-- custom js file link  -->
<script src="../static/js/javascript1.js"></script>
</body>
</html>