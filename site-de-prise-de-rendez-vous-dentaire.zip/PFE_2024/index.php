
<?php  

include './autre_fichiers/component/connect.php';
session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};


?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Applicaion Web d'un cabinet dentaire</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.min.js">
        <link rel="stylesheet" href="./static/css/index1.css">
        <link rel="stylesheet" href="./static/css/header1.css">
        <link rel="stylesheet" href="./static/css/footer.css">

        
        <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
        <script type="text/javascript" src="http://me.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=xODmJNrF8CWXt3FmVE2PuhmlVc9b033PLAjMDcX885mn_hIfM1UW1kdkcYgM7Gcm" charset="UTF-8"></script><link rel="stylesheet" crossorigin="anonymous" href="http://me.kis.v2.scr.kaspersky-labs.com/E3E8934C-235A-4B0E-825A-35A08381A191/abn/main.css?attr=aHR0cDovL2xvY2FsaG9zdC9QRkUv">
    <style>

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .adulte, .enfant {
            text-align: center;
        }
    </style>
</head>
<body>



    <!--Début de la partie header-->
    <header class="header">
            <nav class="navbar nav-1">
                <section class="flex">
                    <a href="./index.php" class="logo">Dental <span>Care.</span></a>
                    <ul>
                        <li><a href="./autre_fichiers/prendre rendez-vous.php">Prendre Rendez-Vous   <i class="fas fa-paper-plane"></i></a>
                    </li>
                    </ul>
                </section>
            </nav>
            <nav class="navbar nav-2">
                <section class="flex">
                    <div id="menu-btn" class="fas fa-bars"></div>
                    <div class="menu">
                        <ul>
                            <li><a href="#home">Accueil </a></li>
                            <?php if($user_id != ''){ ?>
                             <li><a href="./autre_fichiers/res.php">Mes rendez-vous</a></li>
                            <?php } ?></li>
                            <li><a href="#">A propos <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="#cabinet">Cabinet </a></li>
                                    <li><a href="#dentiste">Dentiste</a></li>
                                    <li><a href="#heures">Heures d’ouverture</a></li>
                                    <li><a href="#tarifs">Tarifs</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Services <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="./index.php#implant">Implant Dentaire</a></li><li>
                                    </li><li><a href="./index.php#hollywood">Hollywood Smile</a></li>
                                    <li><a href="./index.php#prothese">Prothèse Dentaire</a></li>
                                    <li><a href="./index.php#blanchiment">Blanchiment Dentaire</a></li>
                                    <li><a href="./index.php#facettes">Facettes Dentaires</a></li>
                                    <li><a href="./index.php#predodontie">Pédodontie</a></li>
                                    <li><a href="./index.php#parod">Parodontologie</a></li>
                                    <li><a href="./index.php#orthodonie">Orthodonie Classique</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Avis <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="./autre_fichiers/commentaire.php">Laisser Un Commentaire </a></li>
                                    <li><a href="./index.php#reviews">Avis Des Clients</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Contact <i class="fas fa-angle-down"></i></a>
                                <ul>
                                    <li><a href="./autre_fichiers/prendre rendez-vous.php">Prendre Rendez-Vous</a></li>
                                    <li><a href="./autre_fichiers/contact.php">Contactez-nous</a></li>
                                    <li><a href="./autre_fichiers/commentaire.php">Laisser Un Commentaire</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <ul>
                    <li><a href="#">Compte <i class="fas fa-angle-down"></i></a>
                    <ul>
                        <?php if($user_id == ''){ ?>
                            <li><a href="./autre_fichiers/login.php">Connexion</a></li>
                            <li><a href="./autre_fichiers/register1.php">Inscription</a></li>
                        <?php } else { ?>
                            <li><a href="./autre_fichiers/update_profile.php">Modifier le profil</a></li>
                            <li><a href="./autre_fichiers/component/user_logout.php" onclick="return confirm('Déconnexion de cette application web ?');">Déconnexion</a></li>
                        <?php } ?>
                    </ul>
            </li>
            </ul>
                </section>
            </nav>
    </header>
        <!--Fin de la partie header-->




    <!--Début de la partie Accueil -->
<div class="home" id="home">
    <section class="center" id="accueil">
        <div class="container">
            <h1>PRENDRE VOTRE SOURIRE EN MAIN</h1>
             <p> 
                Bienvenue Dans Notre Coins Où Chaque Sourire Compte ! Planifiez Votre 
                Prochain Rendez-Vous Dès Maintenant Pour Des Soins Dentaires Exceptionnels
                Et Une Expérience Agréable.

            </p>
            <a href="./autre_fichiers/prendre rendez-vous.php" class="link-btn" target="_blank">Prendre Rendez-Vous   <i class="fas fa-paper-plane"></i></a>
        </div>
    </section>
</div>
    <!-- Fin de la partie Accueil -->



    <!-- Début de la partie a propos-->
    <section class="about" id="about"><br><br><br><br>
        <div class="row" id="cabinet">
            <div class="image" ><br><br>
                <img src="./static/img/propos1.jpg" alt="">
            </div>
            <div class="content">
                <h3>Pourquoi nous choisir ?</h3>
                <p>Lorsque vous choisissez notre cabinet dentaire, vous choisissez l'excellence 
                    sans compromis. Notre engagement envers votre bien-être et votre satisfaction 
                    se reflète dans chaque interaction que vous avez avec notre équipe. Que vous 
                    ayez besoin d'un simple nettoyage ou de traitements dentaires plus avancés, 
                    nous sommes là pour vous offrir des soins personnalisés et attentionnés. Faites 
                    confiance à notre expertise et à notre dévouement pour vous aider à atteindre et à 
                    maintenir un sourire radieux et en santé. Prenez rendez-vous dès maintenant pour prendre 
                    le premier pas vers une meilleure santé bucco-dentaire.
                </p>
                <a href="./autre_fichiers/prendre rendez-vous.php" class="link-btn">Prendre Rendez-Vous </a>
            </div>
        </div><br><br><br><br><br><br><br><br><br><br>
        <div class="row" id="dentiste">
            <div class="image" >
                <img src="./static/img/propos2.jpg" alt="">
            </div>
            <div class="content" >
                <h3>Dentiste propriétaire</h3>
                <p>
                    Dr Dadi Samy a obtenu son diplôme de la faculté de médecine dentaire à l’Université de Sorbonne en 2015.
                     Il commence sa pratique à Alger, où il exerce d’ailleurs encore à temps partiel.
                      À l’été 2017, toujours à la recherche de nouveaux défis, le Dr Dadi va pratiquer dans la belle région de Oran, afin de donner un coup de main, pour les chirurgies et les traitements de canal plus complexes, dans lesquels il excelle.
                       Passionné de dentisterie, Dr Dadi se perfectionne constamment dans plusieurs disciplines, notamment en prosthodontie et réhabilitation complète, en chirurgie ainsi qu’en dentisterie CAD / CAM avec la technologie CEREC.
                        Reconnu pour son professionnalisme et son entregent, il saura sans aucun doute vous mettre en confiance dès le début.
                     C’est avec plaisir qu’il vous rencontrera pour vous conseiller sur vos soins dentaires.
                </p>
                <a href="./autre_fichiers/prendre rendez-vous.php" class="link-btn">Prendre Rendez-Vous </a>
            </div>
        </div>
        <br><br><br><br><br><br><br><br><br><br>
        <div class="row" id="heures">
            <div class="image" >
                <img src="./static/img/img.png" alt="">
            </div>
            <div class="content" >
                <h3>Heures d’ouverture de la clinique dentaire </h3>
                <p>
                Nous sommes là pour répondre à vos besoins tout au long de la semaine ! N'hésitez pas à nous contacter pendant nos heures d’ouverture :<br>
                Samedi : 8 h à 16 h<br>
                Dimanche : 8 h à 16 h<br>
                Lundi : 8 h à 16 h<br>
                Mardi : 8 h à 16 h<br>
                Mercredi : 8 h à 16 h<br>
                Jeudi : 8 h à 16 h<br>
                Vendredi: fermé<br>
                </p>
                <a href="./autre_fichiers/prendre rendez-vous.php" class="link-btn">Prendre Rendez-Vous </a>
            </div>
        </div><br><br><br><br><br><br><br><br><br><br>
        <div class="row" id="tarifs">
            <div class="image" >
                <img src="./static/img/photo1.jpg" alt="">
            </div>
            <div class="content" >
              <h3>Tarifs</h3>
              <table>
        <tr>
            <th>Service</th>
            <th>Adulte (DZD)</th>
            <th>Enfant (DZD)</th>
        </tr>
        <tr>
            <td>Examen</td>
            <td>1500</td>
            <td>1000</td>
        </tr>
        <tr>
            <td>Nettoyage</td>
            <td>2500</td>
            <td>1500</td>
        </tr>
        <tr>
            <td>Orthodontie</td>
            <td>Consultation: 5000</td>
            <td>Consultation: 3000</td>
        </tr>
        <tr>
            <td>Obturation</td>
            <td>2000</td>
            <td>1500</td>
        </tr>
        <tr>
            <td>Chirurgie</td>
            <td>Sur devis</td>
            <td>Sur devis</td>
        </tr>
    </table>       
            </div>
            

    </section>
    <!-- Fin de la partie a propos-->



     <!-- Début de la partie services-->
     <section class="service" id="services">
        <h1 class="heading">Nos services</h1>
        <div class="box-container">
         <div class="box" id="implant">
             <img src="./static/img/service1.jpg" alt="">
             <h3>Implant Dentaire </h3>
             <p>L'implantologie consiste en la mise en place
                 d’un implant dentaire qui remplace la ou les dents manquantes.</p>
            <a href="./autre_fichiers/prendre rendez-vous.php" class="btn" target="_blank">Prendre Rendez-Vous<i class="fas fa-paper-plane"></i></a>
        
         </div>
         <div class="box" id="hollywood">
             <img src="./static/img/service2.jpg" alt="">
             <h3>Hollywood Smile</h3>
             <p>Le Hollywood Smile vous offre la possibilité de dessiner votre sourire selon vos goûts et désirs.</p>
             <a href="./autre_fichiers/prendre rendez-vous.php" class="btn" target="_blank">Prendre Rendez-Vous<i class="fas fa-paper-plane"></i></a>
        
            </div>
         <div class="box" id="prothese">
             <img src="./static/img/service3.jpg" alt="">
             <h3>Prothèse Dentaire</h3>
             <p>C'est un matériel prothétique qu'on place dans la bouche de manière permanente.
            </p>
            <a href="./autre_fichiers/prendre rendez-vous.php" class="btn" target="_blank">Prendre Rendez-Vous<i class="fas fa-paper-plane"></i></a>
        
         </div>
         <div class="box" id="blanchiment">
             <img src="./static/img/service4.jpg" alt="">
             <h3>Blanchiment Dentaire</h3>
             <p>Une technique de dentisterie esthétique visant
                 à éclaircir la teinte des dents qui ont perdu leurs couleurs.</p>
            <a href="./autre_fichiers/prendre rendez-vous.php" class="btn" target="_blank">Prendre Rendez-Vous<i class="fas fa-paper-plane"></i></a>
        
         </div>
         <div class="box" id="facettes">
             <img src="./static/img/service5.jpg" alt="">
             <h3> Facettes dentaires  </h3>
             <p> Les facettes dentaires sont de fines coquilles
                 en porcelaine ou en composite, appliquées sur la surface des dents pour corriger 
                les imperfections et créer un sourire.</p>
            <a href="./autre_fichiers/prendre rendez-vous.php" class="btn" target="_blank">Prendre Rendez-Vous<i class="fas fa-paper-plane"></i></a>
        
         </div>
         <div class="box" id="pedodontie">
             <img src="./static/img/service6.jpg" alt="">
             <h3>Pédodontie</h3>
             <p>Une spécialité qui s'intéresse à l'enfant.Une discipline qui nécessite une connaissance des 
                caractéristiques psychologiques et physiologiques
                 de l'enfant</p>
            <a href="./autre_fichiers/prendre rendez-vous.php" class="btn" target="_blank">Prendre Rendez-Vous<i class="fas fa-paper-plane"></i></a>
        
         </div>
         <div class="box" id="parod">
            <img src="./static/img/service7.jpg" alt="">
            <h3>Parodontologie</h3>
            <p>Une discipline de la médecine dentaire qui concerne le diagnostic,
                 le traitement et la prévention des pathologies qui touchent les tissus
                 de soutien de la dent.</p>
            <a href="./autre_fichiers/prendre rendez-vous.php" class="btn" target="_blank">Prendre Rendez-Vous<i class="fas fa-paper-plane"></i></a>
        
        </div>
        <div class="box" id="orthodonie">
            <img src="./static/img/service8.jpg" alt="">
            <h3>Orthodonie Classique</h3>
            <p>Le traitement orthodontique vise à corriger de nombreuses anomalies de positionnement 
                des dents, comme les défauts
                 d’alignements avec différents appareils.</p>
             <a href="./autre_fichiers/prendre rendez-vous.php" class="btn" target="_blank">Prendre Rendez-Vous<i class="fas fa-paper-plane"></i></a>
        
        </div>
        
        </div>
     </section>

    <!-- Fin de la partie services -->





<!-- Début de la partie Avis des clients -->
<section class="reviews" id="reviews">
    <h1 class="heading">Les avis des clients</h1>

    <div class="box-container">
        <?php
        $select_comments = $conn->prepare("SELECT users.name AS user_name, comments.message, comments.stars FROM `comments` JOIN `users` ON users.email = comments.email WHERE comments.published = 0");
        $select_comments->execute();
        if ($select_comments->rowCount() > 0) {
            while ($fetch_comments = $select_comments->fetch(PDO::FETCH_ASSOC)) {
                // Récupérer le nombre d'étoiles depuis la base de données
                $stars = $fetch_comments['stars'];
                ?>
                <div class="box">
                    <div class="user">

                        <div>
                            <!-- Placeholder pour le nom -->
                            <h3><?= $fetch_comments['user_name']; ?></h3>
                            <div class="starts">
                                <!-- Afficher les étoiles en fonction de la valeur récupérée -->
                                <?php
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $stars) {
                                        echo '<i class="fas fa-star"></i>';
                                    } else {
                                        echo '<i class="far fa-star"></i>';
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                    <!-- Placeholder pour le message -->
                    <p><?= $fetch_comments['message']; ?></p>
                </div>
        <?php
            }
        } else {
            echo '<p class="empty">Vous n\'avez aucun commentaire à publier</p>';
        }
        ?>
    </div>
</section>
<!-- Fin de la partie Avis des clients -->


        <!-- Debut de la partie footer-->
       <footer class="footer">
                <section class="flex">
                    <div class="box">
                        <a href="tel:0559302935"><i class="fas fa-phone"><span>        0559302935</span></i></a>
                        <a href="mailto:dentalCare@gmail.com"><i class="fas fa-envelope"><span>        dentalCare@gmail.com</span></i></a>
                        <a href="#"><i class="fas fa-map-marker-alt"><span>       Alger Tizi-Ouzou </span></i></a>
                        <a href="./autre_fichiers/contact.php"><i class="fas fa-paper-plane"><span>        Contactez-nous</span></i></a>
                        
                    </div>
                    <div class="box">
                        <a href="#home"><span>Accueil</span></a>
                        <a href="#about"><span>A propos</span></a>
                        <a href="#services"><span>Services</span></a>
                        <a href="#reviews"><span>Avis</span></a>
                        <a href="./autre_fichiers/login.php"><span>Prendre rendez-vous</span></a>
                    </div>
                    <div class="box">
                        <a href="#"><i class="bx bxl-facebook"></i>        <span>Facebook</span></a>
                        <a href="#"><i class="bx bxl-twitter"></i>        <span>Twitter</span></a>
                        <a href="#"><i class="bx bxl-linkedin"></i>        <span>Linkedin</span></a>
                        <a href="#"><i class="bx bxl-instagram"></i>        <span>Instagram</span></a>
                    </div>
                </section>
                <div class="credit">©  Droits d'auteur @ 2024 par <span>Mr .Web desinger</span> | Tous droits réservés!</div>
       </footer>
    
    <!-- Fin de la partie footer-->





    <script src="./static/js/javascript1.js"></script>
</body>
</html>